#ifndef WORDSPROCESS_H_
#define WORDSPROCESS_H_


int newSize(const char* str, char* oldWords[], char* newWords[], int n);

void replaceWord(char* str, char* oldWords[], char* newWords[], int n);


#endif