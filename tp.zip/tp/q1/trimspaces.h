#ifndef TRIMSPACES_H_
#define TRIMSPACES_H_

char *trimwhitespace(const char *string);

#endif